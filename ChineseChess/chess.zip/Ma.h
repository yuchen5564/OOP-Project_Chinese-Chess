#ifndef MA_H
#define MA_H

#include "Chess.h"

class Ma : public Chess{
public:
    Ma(){

    }

private:

};


#endif // MA_H
